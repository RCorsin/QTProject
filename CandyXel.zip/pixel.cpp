#include "pixel.h"

pixel::pixel()
{
    done = false;
}
